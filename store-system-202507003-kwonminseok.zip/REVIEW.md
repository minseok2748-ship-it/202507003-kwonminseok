
# REVIEW.md
## 좋았던 점
Kotlin의 객체지향 구조와 함수형 프로그래밍 개념을 실습할 수 있었다.
## 배운 것
컬렉션 함수(`filter`, `map`, `sortedByDescending`)를 통한 데이터 분석 접근법.
## 부족했던 점
콘솔 기반 출력이라 시각적인 UI는 구현하지 못했다.
